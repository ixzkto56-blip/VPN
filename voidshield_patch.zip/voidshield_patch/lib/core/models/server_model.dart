// lib/core/models/server_model.dart

enum VpnProtocol { vless, vmess, trojan, shadowsocks, wireguard, openvpn }

extension VpnProtocolX on VpnProtocol {
  String get label => const {
    VpnProtocol.vless: 'VLESS',
    VpnProtocol.vmess: 'VMess',
    VpnProtocol.trojan: 'Trojan',
    VpnProtocol.shadowsocks: 'Shadowsocks',
    VpnProtocol.wireguard: 'WireGuard',
    VpnProtocol.openvpn: 'OpenVPN',
  }[this]!;

  String get icon => const {
    VpnProtocol.vless: '🔷',
    VpnProtocol.vmess: '🔴',
    VpnProtocol.trojan: '🐴',
    VpnProtocol.shadowsocks: '🌙',
    VpnProtocol.wireguard: '⚡',
    VpnProtocol.openvpn: '🔒',
  }[this]!;

  String get colorHex => const {
    VpnProtocol.vless: 'a29bfe',
    VpnProtocol.vmess: 'fd79a8',
    VpnProtocol.trojan: '00e5a0',
    VpnProtocol.shadowsocks: 'ff9f43',
    VpnProtocol.wireguard: '88b4ff',
    VpnProtocol.openvpn: 'f5c842',
  }[this]!;
}

class VpnServer {
  final String id;
  final String name;
  final String host;
  final int port;
  final VpnProtocol protocol;
  final String flag;
  final String country;
  final int load;
  final String subscriptionId;
  final Map<String, dynamic> extra;
  final int? ping;

  const VpnServer({
    required this.id,
    required this.name,
    required this.host,
    required this.port,
    required this.protocol,
    required this.flag,
    required this.country,
    required this.load,
    this.subscriptionId = '',
    this.extra = const {},
    this.ping,
  });

  VpnServer copyWith({int? ping, String? subscriptionId}) => VpnServer(
    id: id, name: name, host: host, port: port,
    protocol: protocol, flag: flag, country: country, load: load,
    subscriptionId: subscriptionId ?? this.subscriptionId,
    extra: extra, ping: ping ?? this.ping,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'host': host, 'port': port,
    'protocol': protocol.index, 'flag': flag, 'country': country,
    'load': load, 'subscriptionId': subscriptionId, 'extra': extra,
  };

  factory VpnServer.fromJson(Map<String, dynamic> j) => VpnServer(
    id: j['id'], name: j['name'], host: j['host'],
    port: j['port'], protocol: VpnProtocol.values[j['protocol']],
    flag: j['flag'], country: j['country'], load: j['load'],
    subscriptionId: j['subscriptionId'] ?? '',
    extra: Map<String, dynamic>.from(j['extra'] ?? {}),
  );
}

class Subscription {
  final String id;
  final String name;
  final String url;
  final DateTime? expires;
  final List<String> serverIds;

  const Subscription({
    required this.id,
    required this.name,
    required this.url,
    this.expires,
    this.serverIds = const [],
  });

  Subscription copyWith({List<String>? serverIds, DateTime? expires}) => Subscription(
    id: id, name: name, url: url,
    expires: expires ?? this.expires,
    serverIds: serverIds ?? this.serverIds,
  );

  int get daysLeft => expires == null ? 999 : expires!.difference(DateTime.now()).inDays;

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'url': url,
    'expires': expires?.toIso8601String(),
    'serverIds': serverIds,
  };

  factory Subscription.fromJson(Map<String, dynamic> j) => Subscription(
    id: j['id'], name: j['name'], url: j['url'],
    expires: j['expires'] != null ? DateTime.tryParse(j['expires']) : null,
    serverIds: List<String>.from(j['serverIds'] ?? []),
  );
}
