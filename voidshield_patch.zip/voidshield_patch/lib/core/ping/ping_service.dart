// lib/core/ping/ping_service.dart
// Тестирует TCP-соединение до каждого сервера и измеряет задержку

import 'dart:async';
import 'dart:io';
import '../models/server_model.dart';

class PingResult {
  final VpnServer server;
  final int? ping; // null = недоступен
  PingResult(this.server, this.ping);
}

class PingService {
  /// Тестирует все серверы параллельно, возвращает результаты по мере готовности
  static Stream<PingResult> testAll(
    List<VpnServer> servers, {
    int timeoutMs = 3000,
    void Function(String message)? onLog,
  }) async* {
    onLog?.call('Начинаю тестирование ${servers.length} серверов...');

    final futures = servers.map((s) => _testOne(s, timeoutMs, onLog));
    final results = await Future.wait(futures);

    for (final r in results) {
      yield r;
    }
  }

  /// Тестирует один сервер — TCP connect и измеряет время
  static Future<PingResult> _testOne(
    VpnServer server,
    int timeoutMs,
    void Function(String)? onLog,
  ) async {
    onLog?.call('⏳ Тестирую ${server.name} (${server.host}:${server.port})...');
    final sw = Stopwatch()..start();
    try {
      final socket = await Socket.connect(
        server.host,
        server.port,
        timeout: Duration(milliseconds: timeoutMs),
      );
      sw.stop();
      await socket.close();
      final ping = sw.elapsedMilliseconds;
      onLog?.call('✅ ${server.name}: ${ping}ms');
      return PingResult(server, ping);
    } catch (e) {
      sw.stop();
      onLog?.call('❌ ${server.name}: недоступен');
      return PingResult(server, null);
    }
  }

  /// Возвращает лучший (минимальный ping) из результатов
  static VpnServer? bestServer(List<PingResult> results) {
    final reachable = results.where((r) => r.ping != null).toList();
    if (reachable.isEmpty) return null;
    reachable.sort((a, b) => a.ping!.compareTo(b.ping!));
    return reachable.first.server.copyWith(ping: reachable.first.ping);
  }
}
