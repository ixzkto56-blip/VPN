// lib/features/home/view/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math' as math;
import '../../../core/vpn_provider.dart';
import '../../../core/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnProvider>();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 24),
              _Header(),
              const SizedBox(height: 40),
              _PowerButton(vpn: vpn),
              const SizedBox(height: 32),
              _StatusCard(vpn: vpn),
              const SizedBox(height: 20),
              _StatsRow(vpn: vpn),
              const Spacer(),
              _LogPreview(vpn: vpn),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Header ────────────────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            gradient: AppColors.gradientGreen,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(child: Text('🛡', style: TextStyle(fontSize: 20))),
        ),
        const SizedBox(width: 12),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('VoidShield', style: TextStyle(
              color: AppColors.textPrim, fontSize: 20,
              fontWeight: FontWeight.w800, letterSpacing: -0.5,
            )),
            Text('Xray Core', style: TextStyle(
              color: AppColors.textSec, fontSize: 11,
              fontFamily: 'monospace',
            )),
          ],
        ),
        const Spacer(),
        _StatusDot(),
      ],
    );
  }
}

class _StatusDot extends StatefulWidget {
  @override
  State<_StatusDot> createState() => _StatusDotState();
}

class _StatusDotState extends State<_StatusDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _anim = Tween<double>(begin: 0.8, end: 1.4).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnProvider>();
    final color = _statusColor(vpn.status);
    final label = _statusLabel(vpn.status);
    return Row(
      children: [
        if (vpn.isConnected)
          AnimatedBuilder(
            animation: _anim,
            builder: (_, __) => Container(
              width: 10, height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.3),
              ),
              child: Center(
                child: Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color),
                ),
              ),
            ),
          )
        else
          Container(width: 8, height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }
}

// ─── Power Button ──────────────────────────────────────────────────────────

class _PowerButton extends StatefulWidget {
  final VpnProvider vpn;
  const _PowerButton({required this.vpn});

  @override
  State<_PowerButton> createState() => _PowerButtonState();
}

class _PowerButtonState extends State<_PowerButton> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final vpn = widget.vpn;
    final isTesting = vpn.status == VpnStatus.testing || vpn.status == VpnStatus.connecting;
    final isOn = vpn.isConnected;

    return GestureDetector(
      onTap: () => vpn.toggleVpn(),
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, child) {
          return Container(
            width: 160, height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: isOn
                  ? const RadialGradient(colors: [Color(0xFF00E5A0), Color(0xFF007A56)])
                  : isTesting
                  ? const RadialGradient(colors: [Color(0xFFF5C842), Color(0xFF9A7E00)])
                  : const RadialGradient(colors: [Color(0xFF1E2235), Color(0xFF0F1220)]),
              boxShadow: isOn
                  ? [BoxShadow(color: AppColors.green.withOpacity(0.4), blurRadius: 40, spreadRadius: 4)]
                  : isTesting
                  ? [BoxShadow(color: AppColors.yellow.withOpacity(0.3), blurRadius: 30, spreadRadius: 2)]
                  : [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
            ),
            child: isTesting
                ? Transform.rotate(
                    angle: _ctrl.value * 2 * math.pi,
                    child: const Icon(Icons.refresh_rounded, color: Colors.black, size: 48),
                  )
                : Icon(
                    Icons.power_settings_new_rounded,
                    color: isOn ? Colors.black : AppColors.textSec,
                    size: 56,
                  ),
          );
        },
      ),
    );
  }
}

// ─── Status Card ───────────────────────────────────────────────────────────

class _StatusCard extends StatelessWidget {
  final VpnProvider vpn;
  const _StatusCard({required this.vpn});

  @override
  Widget build(BuildContext context) {
    final srv = vpn.activeServer;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: vpn.isConnected ? AppColors.green.withOpacity(0.3) : AppColors.border,
        ),
      ),
      child: vpn.isConnected && srv != null
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Text(srv.flag, style: const TextStyle(fontSize: 28)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(srv.name, style: const TextStyle(
                        color: AppColors.textPrim, fontSize: 17, fontWeight: FontWeight.w700,
                      )),
                      Text(srv.country, style: const TextStyle(color: AppColors.textSec, fontSize: 13)),
                    ],
                  )),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(srv.protocol.label, style: const TextStyle(
                      color: AppColors.green, fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  _Chip(icon: '⏱', label: vpn.formatUptime()),
                  const SizedBox(width: 8),
                  if (srv.ping != null) _Chip(icon: '📶', label: '${srv.ping}ms'),
                  const SizedBox(width: 8),
                  _Chip(icon: '💾', label: srv.host),
                ]),
              ],
            )
          : vpn.status == VpnStatus.testing
          ? const _TestingIndicator()
          : const _DisconnectedHint(),
    );
  }
}

class _Chip extends StatelessWidget {
  final String icon, label;
  const _Chip({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: AppColors.border),
    ),
    child: Row(children: [
      Text(icon, style: const TextStyle(fontSize: 11)),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(
        color: AppColors.textSec, fontSize: 11, fontFamily: 'monospace',
      )),
    ]),
  );
}

class _TestingIndicator extends StatelessWidget {
  const _TestingIndicator();
  @override
  Widget build(BuildContext context) => Row(children: [
    const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(
      strokeWidth: 2, color: AppColors.yellow,
    )),
    const SizedBox(width: 14),
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Тестирую серверы...', style: TextStyle(
        color: AppColors.yellow, fontSize: 15, fontWeight: FontWeight.w600,
      )),
      Text('Выбираю самый быстрый', style: TextStyle(color: AppColors.textSec, fontSize: 12)),
    ]),
  ]);
}

class _DisconnectedHint extends StatelessWidget {
  const _DisconnectedHint();
  @override
  Widget build(BuildContext context) => const Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text('VPN отключён', style: TextStyle(
        color: AppColors.textPrim, fontSize: 17, fontWeight: FontWeight.w700,
      )),
      SizedBox(height: 4),
      Text('Нажми кнопку — выберу самый быстрый сервер автоматически',
        style: TextStyle(color: AppColors.textSec, fontSize: 13)),
    ],
  );
}

// ─── Stats Row ─────────────────────────────────────────────────────────────

class _StatsRow extends StatelessWidget {
  final VpnProvider vpn;
  const _StatsRow({required this.vpn});

  @override
  Widget build(BuildContext context) => Row(children: [
    _StatBox(label: 'Серверов', value: '${vpn.allServers.length}'),
    const SizedBox(width: 12),
    _StatBox(label: 'Подписок', value: '${vpn.subscriptions.length}'),
    const SizedBox(width: 12),
    _StatBox(
      label: 'Лучший пинг',
      value: vpn.pingResults.isEmpty ? '—'
          : '${vpn.pingResults.where((r) => r.ping != null).map((r) => r.ping!).reduce((a, b) => a < b ? a : b)}ms',
    ),
  ]);
}

class _StatBox extends StatelessWidget {
  final String label, value;
  const _StatBox({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(children: [
        Text(value, style: const TextStyle(
          color: AppColors.textPrim, fontSize: 20, fontWeight: FontWeight.w800,
          fontFamily: 'monospace',
        )),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: AppColors.textSec, fontSize: 11)),
      ]),
    ),
  );
}

// ─── Log Preview ───────────────────────────────────────────────────────────

class _LogPreview extends StatelessWidget {
  final VpnProvider vpn;
  const _LogPreview({required this.vpn});

  @override
  Widget build(BuildContext context) {
    final entries = vpn.log.take(3).toList();
    if (entries.isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: entries.map((e) => Padding(
          padding: const EdgeInsets.only(bottom: 3),
          child: Text(e, style: TextStyle(
            fontFamily: 'monospace', fontSize: 11,
            color: e.contains('✅') ? AppColors.green
                : e.contains('❌') ? AppColors.red
                : AppColors.textSec,
          )),
        )).toList(),
      ),
    );
  }
}

// ─── Helpers ───────────────────────────────────────────────────────────────

Color _statusColor(VpnStatus s) => switch (s) {
  VpnStatus.connected    => AppColors.green,
  VpnStatus.testing      => AppColors.yellow,
  VpnStatus.connecting   => AppColors.yellow,
  VpnStatus.disconnected => AppColors.red,
};

String _statusLabel(VpnStatus s) => switch (s) {
  VpnStatus.connected    => 'Подключён',
  VpnStatus.testing      => 'Тестирование...',
  VpnStatus.connecting   => 'Подключение...',
  VpnStatus.disconnected => 'Отключён',
};
