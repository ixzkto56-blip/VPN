// lib/features/subscriptions/view/add_subscription_sheet.dart
// Умное добавление подписки: вставляешь URL → всё определяется автоматически

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../../core/vpn_provider.dart';
import '../../../core/app_theme.dart';
import '../../../core/parser/url_parser.dart';

class AddSubscriptionSheet extends StatefulWidget {
  const AddSubscriptionSheet({super.key});
  @override
  State<AddSubscriptionSheet> createState() => _AddSubscriptionSheetState();
}

class _AddSubscriptionSheetState extends State<AddSubscriptionSheet> {
  final _urlCtrl  = TextEditingController();
  final _nameCtrl = TextEditingController();
  String? _urlError;
  bool _loading = false;
  _DetectedType? _detected;

  @override
  void dispose() { _urlCtrl.dispose(); _nameCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      maxChildSize: 0.92,
      minChildSize: 0.4,
      expand: false,
      builder: (_, scroll) => Container(
        decoration: const BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: ListView(
          controller: scroll,
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 12,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          children: [
            // Handle
            Center(child: Container(
              width: 36, height: 4, margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
            )),
            const Text('Добавить подписку', style: TextStyle(
              color: AppColors.textPrim, fontSize: 20, fontWeight: FontWeight.w800,
            )),
            const SizedBox(height: 6),
            const Text('Вставь ссылку подписки — серверы загрузятся автоматически',
              style: TextStyle(color: AppColors.textSec, fontSize: 13)),
            const SizedBox(height: 24),

            // URL Field
            _Label('URL подписки или сервера'),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: TextField(
                  controller: _urlCtrl,
                  onChanged: _onUrlChanged,
                  style: const TextStyle(
                    color: AppColors.textPrim, fontSize: 13, fontFamily: 'monospace',
                  ),
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText: 'https://sub.example.com/...\nvless://...\nvmess://...',
                    errorText: _urlError,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Column(children: [
                _IconBtn(
                  icon: Icons.content_paste_rounded,
                  tooltip: 'Вставить',
                  onTap: _paste,
                ),
                const SizedBox(height: 8),
                _IconBtn(
                  icon: Icons.clear_rounded,
                  tooltip: 'Очистить',
                  onTap: () { _urlCtrl.clear(); setState(() { _detected = null; _urlError = null; }); },
                ),
              ]),
            ]),

            // Detection result
            if (_detected != null) ...[
              const SizedBox(height: 12),
              _DetectionBadge(detected: _detected!),
            ],

            const SizedBox(height: 20),

            // Name Field
            _Label('Название подписки'),
            const SizedBox(height: 8),
            TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: AppColors.textPrim, fontSize: 14),
              decoration: const InputDecoration(hintText: 'Например: EU Premium'),
            ),

            const SizedBox(height: 24),

            // Supported protocols info
            _ProtocolsInfo(),

            const SizedBox(height: 24),

            // Submit
            SizedBox(
              height: 52,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: AppColors.gradientGreen,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: TextButton(
                  onPressed: _loading ? null : _submit,
                  child: _loading
                      ? const SizedBox(width: 22, height: 22,
                          child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2.5))
                      : const Text('Добавить подписку', style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w800, fontSize: 16)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onUrlChanged(String val) {
    setState(() {
      _urlError = null;
      _detected = _detect(val.trim());
      // Автозаполнение имени из URL
      if (_nameCtrl.text.isEmpty && val.isNotEmpty) {
        try {
          final uri = Uri.parse(val);
          _nameCtrl.text = uri.host.isNotEmpty ? uri.host : 'Моя подписка';
        } catch (_) {}
      }
    });
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData('text/plain');
    if (data?.text != null) {
      _urlCtrl.text = data!.text!;
      _onUrlChanged(data.text!);
    }
  }

  _DetectedType _detect(String url) {
    if (url.startsWith('vless://'))      return _DetectedType('VLESS', '🔷', AppColors.purple, _TypeKind.single);
    if (url.startsWith('vmess://'))      return _DetectedType('VMess', '🔴', const Color(0xFFfd79a8), _TypeKind.single);
    if (url.startsWith('trojan://'))     return _DetectedType('Trojan', '🐴', AppColors.green, _TypeKind.single);
    if (url.startsWith('ss://'))         return _DetectedType('Shadowsocks', '🌙', const Color(0xFFff9f43), _TypeKind.single);
    if (url.startsWith('wireguard://'))  return _DetectedType('WireGuard', '⚡', const Color(0xFF88b4ff), _TypeKind.single);
    if (url.startsWith('openvpn://'))    return _DetectedType('OpenVPN', '🔒', AppColors.yellow, _TypeKind.single);
    if (url.startsWith('http'))          return _DetectedType('Список серверов', '📦', AppColors.blue, _TypeKind.subscription);
    return _DetectedType('Неизвестно', '❓', AppColors.textSec, _TypeKind.unknown);
  }

  Future<void> _submit() async {
    final url = _urlCtrl.text.trim();
    final name = _nameCtrl.text.trim();

    if (url.isEmpty) { setState(() => _urlError = 'Вставь ссылку'); return; }
    if (name.isEmpty) { setState(() => _urlError = 'Укажи название'); return; }

    setState(() => _loading = true);
    final vpn = context.read<VpnProvider>();

    // Если это одиночный сервер — добавляем напрямую
    if (_detected?.kind == _TypeKind.single) {
      final ok = vpn.addServerFromUrl(url);
      if (!mounted) return;
      if (ok) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Сервер добавлен'), backgroundColor: AppColors.green),
        );
      } else {
        setState(() { _urlError = 'Не удалось разобрать ссылку'; _loading = false; });
      }
      return;
    }

    // Иначе — добавляем как подписку
    final ok = await vpn.addSubscriptionFromUrl(url, name);
    if (!mounted) return;
    setState(() => _loading = false);
    if (ok) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('✅ Подписка "$name" добавлена'), backgroundColor: AppColors.green),
      );
    } else {
      setState(() => _urlError = 'Не удалось загрузить подписку');
    }
  }
}

// ─── Detection Badge ───────────────────────────────────────────────────────

enum _TypeKind { single, subscription, unknown }

class _DetectedType {
  final String label, icon;
  final Color color;
  final _TypeKind kind;
  const _DetectedType(this.label, this.icon, this.color, this.kind);
}

class _DetectionBadge extends StatelessWidget {
  final _DetectedType detected;
  const _DetectionBadge({required this.detected});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(
      color: detected.color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: detected.color.withOpacity(0.3)),
    ),
    child: Row(children: [
      Text(detected.icon, style: const TextStyle(fontSize: 18)),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Определён протокол', style: TextStyle(color: detected.color.withOpacity(0.7), fontSize: 11)),
        Text(detected.label, style: TextStyle(color: detected.color, fontSize: 14, fontWeight: FontWeight.w700)),
      ]),
      const Spacer(),
      Icon(Icons.check_circle, color: detected.color, size: 20),
    ]),
  );
}

// ─── Protocols Info ────────────────────────────────────────────────────────

class _ProtocolsInfo extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Поддерживаемые протоколы', style: TextStyle(
          color: AppColors.textSec, fontSize: 12, fontWeight: FontWeight.w600,
        )),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: const [
          _ProtoChip('🔷 VLESS',       Color(0xFFa29bfe)),
          _ProtoChip('🔴 VMess',       Color(0xFFfd79a8)),
          _ProtoChip('🐴 Trojan',      Color(0xFF00e5a0)),
          _ProtoChip('🌙 Shadowsocks', Color(0xFFff9f43)),
          _ProtoChip('⚡ WireGuard',   Color(0xFF88b4ff)),
          _ProtoChip('🔒 OpenVPN',     Color(0xFFf5c842)),
        ]),
      ],
    ),
  );
}

class _ProtoChip extends StatelessWidget {
  final String label;
  final Color color;
  const _ProtoChip(this.label, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
    style: const TextStyle(color: AppColors.textSec, fontSize: 12, fontWeight: FontWeight.w600));
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Icon(icon, color: AppColors.textSec, size: 20),
      ),
    ),
  );
}
