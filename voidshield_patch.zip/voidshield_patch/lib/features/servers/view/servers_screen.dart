// lib/features/servers/view/servers_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/vpn_provider.dart';
import '../../../core/app_theme.dart';
import '../../../core/models/server_model.dart';
import '../../subscriptions/view/add_subscription_sheet.dart';

class ServersScreen extends StatelessWidget {
  const ServersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnProvider>();
    final subs = vpn.subscriptions;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Серверы'),
        actions: [
          // Фильтр по подписке
          if (subs.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: vpn.filterSubId,
                  dropdownColor: AppColors.card,
                  style: const TextStyle(color: AppColors.textSec, fontSize: 13),
                  icon: const Icon(Icons.filter_list, color: AppColors.textSec, size: 18),
                  items: [
                    const DropdownMenuItem(value: 'all', child: Text('Все')),
                    ...subs.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))),
                  ],
                  onChanged: (v) => vpn.setFilter(v ?? 'all'),
                ),
              ),
            ),
          IconButton(
            icon: const Icon(Icons.add, color: AppColors.green),
            onPressed: () => _showAddServer(context),
          ),
        ],
      ),
      body: vpn.servers.isEmpty
          ? _EmptyState(onAdd: () => _showAddServer(context))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: vpn.servers.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) => _ServerCard(server: vpn.servers[i]),
            ),
    );
  }

  void _showAddServer(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => const _AddServerSheet(),
    );
  }
}

// ─── Server Card ───────────────────────────────────────────────────────────

class _ServerCard extends StatelessWidget {
  final VpnServer server;
  const _ServerCard({required this.server});

  @override
  Widget build(BuildContext context) {
    final vpn = context.read<VpnProvider>();
    final isActive = context.watch<VpnProvider>().activeServer?.id == server.id;
    final proto = server.protocol;
    final protoColor = Color(int.parse('FF${proto.colorHex}', radix: 16));

    return Container(
      decoration: BoxDecoration(
        color: isActive ? AppColors.green.withOpacity(0.07) : AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive ? AppColors.green.withOpacity(0.4) : AppColors.border,
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            Text(server.flag, style: const TextStyle(fontSize: 32)),
            Positioned(
              right: -4, bottom: -2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  color: protoColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: protoColor.withOpacity(0.5)),
                ),
                child: Text(proto.icon, style: const TextStyle(fontSize: 9)),
              ),
            ),
          ],
        ),
        title: Row(children: [
          Expanded(child: Text(server.name, style: const TextStyle(
            color: AppColors.textPrim, fontWeight: FontWeight.w600, fontSize: 15,
          ))),
          if (isActive) Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: AppColors.green.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            child: const Text('ACTIVE', style: TextStyle(
              color: AppColors.green, fontSize: 10, fontWeight: FontWeight.w800,
            )),
          ),
        ]),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Row(children: [
              Text(server.host, style: const TextStyle(
                color: AppColors.textSec, fontSize: 11, fontFamily: 'monospace',
              )),
              const Text(' : ', style: TextStyle(color: AppColors.border, fontSize: 11)),
              Text('${server.port}', style: const TextStyle(
                color: AppColors.textSec, fontSize: 11, fontFamily: 'monospace',
              )),
            ]),
            const SizedBox(height: 6),
            Row(children: [
              Text(proto.label, style: TextStyle(color: protoColor, fontSize: 11, fontWeight: FontWeight.w600)),
              const SizedBox(width: 10),
              _PingBar(ping: server.ping, load: server.load),
            ]),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, color: AppColors.textSec, size: 20),
          onPressed: () => _confirmDelete(context, vpn),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, VpnProvider vpn) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Удалить сервер?', style: TextStyle(color: AppColors.textPrim)),
        content: Text('${server.name} будет удалён', style: const TextStyle(color: AppColors.textSec)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          TextButton(
            onPressed: () { vpn.deleteServer(server.id); Navigator.pop(context); },
            child: const Text('Удалить', style: TextStyle(color: AppColors.red)),
          ),
        ],
      ),
    );
  }
}

// ─── Ping Bar ──────────────────────────────────────────────────────────────

class _PingBar extends StatelessWidget {
  final int? ping;
  final int load;
  const _PingBar({this.ping, required this.load});

  @override
  Widget build(BuildContext context) {
    final color = ping == null ? AppColors.textSec
        : ping! < 80 ? AppColors.green
        : ping! < 150 ? AppColors.yellow
        : AppColors.red;
    return Row(children: [
      SizedBox(
        width: 60, height: 4,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(
            value: ping == null ? 0 : (1 - (ping! / 300).clamp(0, 1)),
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation(color),
          ),
        ),
      ),
      const SizedBox(width: 6),
      Text(
        ping == null ? '—' : '${ping}ms',
        style: TextStyle(color: color, fontSize: 11, fontFamily: 'monospace'),
      ),
    ]);
  }
}

// ─── Add Server Sheet ──────────────────────────────────────────────────────

class _AddServerSheet extends StatefulWidget {
  const _AddServerSheet();
  @override
  State<_AddServerSheet> createState() => _AddServerSheetState();
}

class _AddServerSheetState extends State<_AddServerSheet> {
  final _ctrl = TextEditingController();
  String? _error;
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 24,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle
          Center(child: Container(
            width: 36, height: 4,
            decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
          )),
          const SizedBox(height: 20),
          const Text('Добавить сервер', style: TextStyle(
            color: AppColors.textPrim, fontSize: 18, fontWeight: FontWeight.w700,
          )),
          const SizedBox(height: 8),
          const Text('Вставь ссылку сервера — протокол определится автоматически',
            style: TextStyle(color: AppColors.textSec, fontSize: 13)),
          const SizedBox(height: 6),
          // Protocol badges
          Wrap(spacing: 6, runSpacing: 6, children: [
            'vless://', 'vmess://', 'trojan://',
            'ss://', 'wireguard://', 'openvpn://',
          ].map((p) => Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.border),
            ),
            child: Text(p, style: const TextStyle(color: AppColors.textSec, fontSize: 11, fontFamily: 'monospace')),
          )).toList()),
          const SizedBox(height: 16),
          TextField(
            controller: _ctrl,
            style: const TextStyle(color: AppColors.textPrim, fontSize: 13, fontFamily: 'monospace'),
            maxLines: 4,
            decoration: InputDecoration(
              hintText: 'vless://uuid@host:port?...',
              errorText: _error,
              suffixIcon: IconButton(
                icon: const Icon(Icons.paste, color: AppColors.textSec),
                onPressed: () async {
                  // paste from clipboard
                },
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: AppColors.gradientGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: TextButton(
                onPressed: _loading ? null : _submit,
                child: _loading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                    : const Text('Добавить', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w700, fontSize: 15)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _submit() {
    final url = _ctrl.text.trim();
    if (url.isEmpty) { setState(() => _error = 'Вставь ссылку сервера'); return; }
    final vpn = context.read<VpnProvider>();
    final ok = vpn.addServerFromUrl(url);
    if (ok) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Сервер добавлен'), backgroundColor: AppColors.green),
      );
    } else {
      setState(() => _error = 'Неверный формат ссылки');
    }
  }
}

// ─── Empty State ───────────────────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('🖥', style: TextStyle(fontSize: 56)),
        const SizedBox(height: 16),
        const Text('Нет серверов', style: TextStyle(
          color: AppColors.textPrim, fontSize: 18, fontWeight: FontWeight.w700,
        )),
        const SizedBox(height: 8),
        const Text('Добавь сервер или подписку', style: TextStyle(color: AppColors.textSec)),
        const SizedBox(height: 24),
        GestureDetector(
          onTap: onAdd,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              gradient: AppColors.gradientGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Text('+ Добавить сервер', style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.w700,
            )),
          ),
        ),
      ],
    ),
  );
}
