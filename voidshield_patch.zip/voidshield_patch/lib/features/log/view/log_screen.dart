// lib/features/log/view/log_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/vpn_provider.dart';
import '../../../core/app_theme.dart';

class LogScreen extends StatelessWidget {
  const LogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Лог'),
        actions: [
          TextButton(
            onPressed: vpn.log.isEmpty ? null : vpn.clearLog,
            child: Text('Очистить',
              style: TextStyle(color: vpn.log.isEmpty ? AppColors.textSec : AppColors.red)),
          ),
        ],
      ),
      body: vpn.log.isEmpty
          ? const Center(child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('📋', style: TextStyle(fontSize: 48)),
                SizedBox(height: 12),
                Text('Лог пуст', style: TextStyle(color: AppColors.textSec, fontSize: 16)),
                SizedBox(height: 4),
                Text('Подключись к VPN чтобы видеть события',
                  style: TextStyle(color: AppColors.textSec, fontSize: 13)),
              ],
            ))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: vpn.log.length,
              itemBuilder: (_, i) {
                final entry = vpn.log[i];
                final color = entry.contains('✅') ? AppColors.green
                    : entry.contains('❌') ? AppColors.red
                    : entry.contains('🔍') || entry.contains('⏳') ? AppColors.yellow
                    : AppColors.textSec;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 3, height: 36,
                        margin: const EdgeInsets.only(right: 10, top: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      Expanded(child: Text(entry,
                        style: TextStyle(color: color, fontSize: 12, fontFamily: 'monospace', height: 1.5),
                      )),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
