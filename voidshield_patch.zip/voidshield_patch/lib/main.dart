// lib/main.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/vpn_provider.dart';
import 'core/app_theme.dart';
import 'features/home/view/home_screen.dart';
import 'features/servers/view/servers_screen.dart';
import 'features/subscriptions/view/subscriptions_screen.dart';
import 'features/log/view/log_screen.dart';
import 'features/subscriptions/view/add_subscription_sheet.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF060812),
  ));
  runApp(
    ChangeNotifierProvider(
      create: (_) => VpnProvider(),
      child: const VoidShieldApp(),
    ),
  );
}

class VoidShieldApp extends StatelessWidget {
  const VoidShieldApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VoidShield',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.dark,
    home: const _RootScreen(),
  );
}

class _RootScreen extends StatefulWidget {
  const _RootScreen();
  @override
  State<_RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<_RootScreen> {
  int _tab = 0;

  static const _screens = [
    HomeScreen(),
    ServersScreen(),
    SubscriptionsScreen(),
    LogScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _tab, children: _screens),
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => const AddSubscriptionSheet(),
              ),
              backgroundColor: AppColors.green,
              foregroundColor: Colors.black,
              icon: const Icon(Icons.add),
              label: const Text('Подписка', style: TextStyle(fontWeight: FontWeight.w700)),
            )
          : null,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.surface,
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: BottomNavigationBar(
          currentIndex: _tab,
          onTap: (i) => setState(() => _tab = i),
          backgroundColor: Colors.transparent,
          elevation: 0,
          selectedItemColor: AppColors.green,
          unselectedItemColor: AppColors.textSec,
          type: BottomNavigationBarType.fixed,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.shield_rounded),       label: 'Главная'),
            BottomNavigationBarItem(icon: Icon(Icons.dns_rounded),           label: 'Серверы'),
            BottomNavigationBarItem(icon: Icon(Icons.subscriptions_rounded), label: 'Подписки'),
            BottomNavigationBarItem(icon: Icon(Icons.terminal_rounded),      label: 'Лог'),
          ],
        ),
      ),
    );
  }
}
