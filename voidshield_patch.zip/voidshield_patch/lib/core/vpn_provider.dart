// lib/core/vpn_provider.dart
// Главный провайдер состояния — серверы, подписки, VPN статус

import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/server_model.dart';
import 'ping/ping_service.dart';
import 'parser/url_parser.dart';

enum VpnStatus { disconnected, testing, connecting, connected }

class VpnProvider extends ChangeNotifier {
  List<VpnServer> _servers = [];
  List<Subscription> _subscriptions = [];
  VpnStatus _status = VpnStatus.disconnected;
  VpnServer? _activeServer;
  final List<String> _log = [];
  Duration _uptime = Duration.zero;
  Timer? _uptimeTimer;
  List<PingResult> _pingResults = [];
  String _filterSubId = 'all';

  List<VpnServer> get servers => _filterSubId == 'all'
      ? _servers
      : _servers.where((s) => s.subscriptionId == _filterSubId).toList();

  List<VpnServer> get allServers => _servers;
  List<Subscription> get subscriptions => _subscriptions;
  VpnStatus get status => _status;
  VpnServer? get activeServer => _activeServer;
  List<String> get log => List.unmodifiable(_log);
  List<PingResult> get pingResults => _pingResults;
  Duration get uptime => _uptime;
  String get filterSubId => _filterSubId;
  bool get isConnected => _status == VpnStatus.connected;

  VpnProvider() { _load(); }

  // ─── VPN Toggle ────────────────────────────────────────────────────────────

  Future<void> toggleVpn() async {
    if (_status == VpnStatus.connected) {
      _disconnect();
      return;
    }
    if (_status == VpnStatus.testing || _status == VpnStatus.connecting) return;
    await _connectAuto();
  }

  void _disconnect() {
    _status = VpnStatus.disconnected;
    _activeServer = null;
    _uptimeTimer?.cancel();
    _uptime = Duration.zero;
    _pingResults = [];
    _servers = _servers.map((s) => s.copyWith(ping: null)).toList();
    _addLog('🔴 VPN отключён');
    notifyListeners();
  }

  Future<void> _connectAuto() async {
    _status = VpnStatus.testing;
    _pingResults = [];
    _addLog('🔍 Начинаю тестирование серверов...');
    notifyListeners();

    final targets = servers; // уже отфильтрованы
    if (targets.isEmpty) {
      _addLog('❌ Нет серверов для тестирования');
      _status = VpnStatus.disconnected;
      notifyListeners();
      return;
    }

    // Тестируем все серверы
    await for (final result in PingService.testAll(targets, onLog: _addLog)) {
      _pingResults.add(result);
      // Обновляем ping в списке серверов
      _servers = _servers.map((s) =>
        s.id == result.server.id ? s.copyWith(ping: result.ping) : s
      ).toList();
      notifyListeners();
    }

    final best = PingService.bestServer(_pingResults);
    if (best == null) {
      _addLog('❌ Все серверы недоступны');
      _status = VpnStatus.disconnected;
      notifyListeners();
      return;
    }

    _status = VpnStatus.connecting;
    _addLog('🔗 Подключаюсь к ${best.name} (${best.ping}ms)...');
    notifyListeners();

    // Здесь вызывается Hiddify/Xray core для реального подключения
    // await HiddifyCore.connect(best);
    await Future.delayed(const Duration(milliseconds: 800));

    _activeServer = best;
    _status = VpnStatus.connected;
    _startUptimeTimer();
    _addLog('✅ Подключено: ${best.name} — ${best.ping}ms');
    notifyListeners();
  }

  void _startUptimeTimer() {
    _uptime = Duration.zero;
    _uptimeTimer?.cancel();
    _uptimeTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _uptime += const Duration(seconds: 1);
      notifyListeners();
    });
  }

  // ─── Servers ───────────────────────────────────────────────────────────────

  bool addServerFromUrl(String url, {String subscriptionId = ''}) {
    final server = VpnUrlParser.parse(url);
    if (server == null) return false;
    _servers.add(server.copyWith(subscriptionId: subscriptionId));
    _save();
    notifyListeners();
    return true;
  }

  void deleteServer(String id) {
    if (_activeServer?.id == id) _disconnect();
    _servers.removeWhere((s) => s.id == id);
    _subscriptions = _subscriptions.map((sub) => sub.copyWith(
      serverIds: sub.serverIds.where((sid) => sid != id).toList(),
    )).toList();
    _save();
    notifyListeners();
  }

  void setFilter(String subId) {
    _filterSubId = subId;
    notifyListeners();
  }

  // ─── Subscriptions ─────────────────────────────────────────────────────────

  void addSubscription(Subscription sub) {
    _subscriptions.add(sub);
    _save();
    notifyListeners();
  }

  /// Добавляет подписку по URL и загружает серверы из неё
  Future<bool> addSubscriptionFromUrl(String url, String name) async {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final sub = Subscription(id: id, name: name, url: url);
    _subscriptions.add(sub);
    _addLog('📦 Подписка "$name" добавлена');
    notifyListeners();

    // Пытаемся загрузить серверы из URL
    await refreshSubscription(id);
    return true;
  }

  /// Обновляет серверы из URL подписки
  Future<void> refreshSubscription(String subId) async {
    final sub = _subscriptions.firstWhere((s) => s.id == subId, orElse: () => throw Exception('Not found'));
    _addLog('🔄 Обновляю подписку "${sub.name}"...');
    notifyListeners();

    try {
      // В реальном приложении здесь HTTP запрос к sub.url
      // Ответ — список ссылок (одна на строку) или base64
      // final resp = await http.get(Uri.parse(sub.url));
      // final lines = utf8.decode(resp.bodyBytes).split('\n');

      // Для демонстрации — просто логируем
      _addLog('✅ Подписка "${sub.name}" обновлена');
    } catch (e) {
      _addLog('❌ Ошибка обновления: $e');
    }
    notifyListeners();
  }

  void deleteSubscription(String id) {
    if (_subscriptions.every((s) => s.id != id)) return;
    final sub = _subscriptions.firstWhere((s) => s.id == id);
    // Удаляем все серверы этой подписки
    for (final sid in sub.serverIds) {
      if (_activeServer?.id == sid) _disconnect();
    }
    _servers.removeWhere((s) => s.subscriptionId == id);
    _subscriptions.removeWhere((s) => s.id == id);
    if (_filterSubId == id) _filterSubId = 'all';
    _save();
    notifyListeners();
  }

  // ─── Log ───────────────────────────────────────────────────────────────────

  void _addLog(String msg) {
    final time = DateTime.now();
    final hms = '${time.hour.toString().padLeft(2,'0')}:${time.minute.toString().padLeft(2,'0')}:${time.second.toString().padLeft(2,'0')}';
    _log.insert(0, '$hms — $msg');
    if (_log.length > 100) _log.removeLast();
  }

  void clearLog() { _log.clear(); notifyListeners(); }

  // ─── Persistence ───────────────────────────────────────────────────────────

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('servers', jsonEncode(_servers.map((s) => s.toJson()).toList()));
    prefs.setString('subscriptions', jsonEncode(_subscriptions.map((s) => s.toJson()).toList()));
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final sv = prefs.getString('servers');
    final sb = prefs.getString('subscriptions');
    if (sv != null) {
      _servers = (jsonDecode(sv) as List).map((j) => VpnServer.fromJson(j)).toList();
    }
    if (sb != null) {
      _subscriptions = (jsonDecode(sb) as List).map((j) => Subscription.fromJson(j)).toList();
    }
    notifyListeners();
  }

  String formatUptime() {
    final h = _uptime.inHours.toString().padLeft(2, '0');
    final m = (_uptime.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_uptime.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }
}
