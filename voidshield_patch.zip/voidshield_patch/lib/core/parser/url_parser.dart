// lib/core/parser/url_parser.dart
// Парсит ссылки всех протоколов: VLESS, VMess, Trojan, Shadowsocks, WireGuard, OpenVPN

import 'dart:convert';
import '../models/server_model.dart';

class VpnUrlParser {
  /// Главный метод — определяет протокол и парсит
  static VpnServer? parse(String raw) {
    final url = raw.trim();
    if (url.startsWith('vless://'))       return _parseVless(url);
    if (url.startsWith('vmess://'))       return _parseVmess(url);
    if (url.startsWith('trojan://'))      return _parseTrojan(url);
    if (url.startsWith('ss://'))          return _parseShadowsocks(url);
    if (url.startsWith('wireguard://'))   return _parseWireGuard(url);
    if (url.startsWith('openvpn://'))     return _parseOpenVpn(url);
    return null;
  }

  /// VLESS: vless://uuid@host:port?type=tcp&security=tls#name
  static VpnServer? _parseVless(String url) {
    try {
      final uri = Uri.parse(url.replaceFirst('vless://', 'https://'));
      final uuid = uri.userInfo;
      final host = uri.host;
      final port = uri.port;
      final name = Uri.decodeComponent(uri.fragment.isNotEmpty ? uri.fragment : host);
      final params = uri.queryParameters;
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: port,
        protocol: VpnProtocol.vless,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: {
          'uuid': uuid,
          'type': params['type'] ?? 'tcp',
          'security': params['security'] ?? 'none',
          'sni': params['sni'] ?? '',
          'flow': params['flow'] ?? '',
          'fp': params['fp'] ?? '',
          'pbk': params['pbk'] ?? '',
          'sid': params['sid'] ?? '',
        },
      );
    } catch (_) { return null; }
  }

  /// VMess: vmess://base64(json)
  static VpnServer? _parseVmess(String url) {
    try {
      final b64 = url.replaceFirst('vmess://', '');
      final json = utf8.decode(base64Url.decode(base64Url.normalize(b64)));
      final Map<String, dynamic> cfg = jsonDecode(json);
      final host = cfg['add'] ?? '';
      final name = cfg['ps'] ?? cfg['remarks'] ?? host;
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: int.tryParse(cfg['port'].toString()) ?? 443,
        protocol: VpnProtocol.vmess,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: {
          'uuid': cfg['id'] ?? '',
          'alterId': cfg['aid'] ?? 0,
          'network': cfg['net'] ?? 'tcp',
          'security': cfg['tls'] ?? 'none',
          'sni': cfg['sni'] ?? cfg['host'] ?? '',
          'path': cfg['path'] ?? '',
        },
      );
    } catch (_) { return null; }
  }

  /// Trojan: trojan://password@host:port?sni=...#name
  static VpnServer? _parseTrojan(String url) {
    try {
      final uri = Uri.parse(url.replaceFirst('trojan://', 'https://'));
      final host = uri.host;
      final name = Uri.decodeComponent(uri.fragment.isNotEmpty ? uri.fragment : host);
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: uri.port,
        protocol: VpnProtocol.trojan,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: {
          'password': uri.userInfo,
          'sni': uri.queryParameters['sni'] ?? host,
          'allowInsecure': uri.queryParameters['allowInsecure'] ?? '0',
        },
      );
    } catch (_) { return null; }
  }

  /// Shadowsocks: ss://base64(method:password)@host:port#name
  static VpnServer? _parseShadowsocks(String url) {
    try {
      final uri = Uri.parse(url.replaceFirst('ss://', 'https://'));
      String method = '', password = '';
      final userInfo = uri.userInfo;

      // Попробуем декодировать как base64
      try {
        final decoded = utf8.decode(base64Url.decode(base64Url.normalize(userInfo)));
        final parts = decoded.split(':');
        method = parts[0];
        password = parts.sublist(1).join(':');
      } catch (_) {
        // SIP002 формат: method:password уже в plain
        final parts = userInfo.split(':');
        method = parts[0];
        password = parts.sublist(1).join(':');
      }

      final host = uri.host;
      final name = Uri.decodeComponent(uri.fragment.isNotEmpty ? uri.fragment : host);
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: uri.port,
        protocol: VpnProtocol.shadowsocks,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: { 'method': method, 'password': password },
      );
    } catch (_) { return null; }
  }

  /// WireGuard: wireguard://privkey@host:port?publickey=...&presharedkey=...&reserved=...&address=...#name
  static VpnServer? _parseWireGuard(String url) {
    try {
      final uri = Uri.parse(url.replaceFirst('wireguard://', 'https://'));
      final host = uri.host;
      final name = Uri.decodeComponent(uri.fragment.isNotEmpty ? uri.fragment : host);
      final params = uri.queryParameters;
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: uri.port == 0 ? 51820 : uri.port,
        protocol: VpnProtocol.wireguard,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: {
          'privateKey': Uri.decodeComponent(uri.userInfo),
          'publicKey': params['publickey'] ?? '',
          'presharedKey': params['presharedkey'] ?? '',
          'reserved': params['reserved'] ?? '',
          'address': params['address'] ?? '10.0.0.1/32',
          'dns': params['dns'] ?? '1.1.1.1',
          'mtu': params['mtu'] ?? '1280',
        },
      );
    } catch (_) { return null; }
  }

  /// OpenVPN: openvpn://user:pass@host:port#name  или просто ссылка на .ovpn файл
  static VpnServer? _parseOpenVpn(String url) {
    try {
      final uri = Uri.parse(url.replaceFirst('openvpn://', 'https://'));
      final host = uri.host;
      final name = Uri.decodeComponent(uri.fragment.isNotEmpty ? uri.fragment : host);
      return VpnServer(
        id: _uid(),
        name: name,
        host: host,
        port: uri.port == 0 ? 1194 : uri.port,
        protocol: VpnProtocol.openvpn,
        flag: _flagFromHost(host),
        country: _countryFromHost(host),
        load: _randomLoad(),
        extra: {
          'username': uri.userInfo.split(':').first,
          'password': uri.userInfo.contains(':') ? uri.userInfo.split(':').last : '',
        },
      );
    } catch (_) { return null; }
  }

  // ─── Helpers ───────────────────────────────────────────────────────────────

  static final _flagMap = {
    'de': ['🇩🇪', 'Germany'],   'fr': ['🇫🇷', 'France'],
    'nl': ['🇳🇱', 'Netherlands'], 'us': ['🇺🇸', 'USA'],
    'uk': ['🇬🇧', 'UK'],         'gb': ['🇬🇧', 'UK'],
    'jp': ['🇯🇵', 'Japan'],       'sg': ['🇸🇬', 'Singapore'],
    'ca': ['🇨🇦', 'Canada'],      'au': ['🇦🇺', 'Australia'],
    'ru': ['🇷🇺', 'Russia'],      'fi': ['🇫🇮', 'Finland'],
    'se': ['🇸🇪', 'Sweden'],      'no': ['🇳🇴', 'Norway'],
    'ch': ['🇨🇭', 'Switzerland'], 'at': ['🇦🇹', 'Austria'],
    'tr': ['🇹🇷', 'Turkey'],      'in': ['🇮🇳', 'India'],
    'kr': ['🇰🇷', 'South Korea'], 'hk': ['🇭🇰', 'Hong Kong'],
    'br': ['🇧🇷', 'Brazil'],      'pl': ['🇵🇱', 'Poland'],
    'ua': ['🇺🇦', 'Ukraine'],     'cz': ['🇨🇿', 'Czech Republic'],
  };

  static String _flagFromHost(String host) {
    final h = host.toLowerCase();
    for (final e in _flagMap.entries) {
      if (h.contains('.${e.key}.') || h.startsWith('${e.key}.') || h.contains('-${e.key}-') || h.contains('-${e.key}.')) {
        return e.value[0];
      }
    }
    return '🌍';
  }

  static String _countryFromHost(String host) {
    final h = host.toLowerCase();
    for (final e in _flagMap.entries) {
      if (h.contains('.${e.key}.') || h.startsWith('${e.key}.') || h.contains('-${e.key}-') || h.contains('-${e.key}.')) {
        return e.value[1];
      }
    }
    return 'Unknown';
  }

  static int _randomLoad() => 20 + DateTime.now().millisecond % 60;

  static String _uid() => DateTime.now().microsecondsSinceEpoch.toString();
}
