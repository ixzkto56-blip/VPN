// lib/features/subscriptions/view/subscriptions_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/vpn_provider.dart';
import '../../../core/app_theme.dart';
import '../../../core/models/server_model.dart';
import 'add_subscription_sheet.dart';

class SubscriptionsScreen extends StatelessWidget {
  const SubscriptionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vpn = context.watch<VpnProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Подписки'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: AppColors.green),
            onPressed: () => _showAddSheet(context),
          ),
        ],
      ),
      body: vpn.subscriptions.isEmpty
          ? _EmptyState(onAdd: () => _showAddSheet(context))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: vpn.subscriptions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, i) => _SubCard(sub: vpn.subscriptions[i]),
            ),
    );
  }

  void _showAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const AddSubscriptionSheet(),
    );
  }
}

class _SubCard extends StatelessWidget {
  final Subscription sub;
  const _SubCard({required this.sub});

  @override
  Widget build(BuildContext context) {
    final vpn = context.read<VpnProvider>();
    final servers = vpn.allServers.where((s) => s.subscriptionId == sub.id).toList();
    final daysLeft = sub.daysLeft;
    final expiryColor = daysLeft < 7 ? AppColors.red
        : daysLeft < 30 ? AppColors.yellow
        : AppColors.green;

    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 8, 12),
            child: Row(children: [
              const Text('📦', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(sub.name, style: const TextStyle(
                    color: AppColors.textPrim, fontSize: 16, fontWeight: FontWeight.w700,
                  )),
                  const SizedBox(height: 2),
                  Text(sub.url, style: const TextStyle(
                    color: AppColors.textSec, fontSize: 11, fontFamily: 'monospace',
                  ), maxLines: 1, overflow: TextOverflow.ellipsis),
                ],
              )),
              PopupMenuButton<String>(
                color: AppColors.surface,
                icon: const Icon(Icons.more_vert, color: AppColors.textSec),
                onSelected: (v) {
                  if (v == 'refresh') vpn.refreshSubscription(sub.id);
                  if (v == 'delete') _confirmDelete(context, vpn);
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'refresh', child: Row(children: [
                    Icon(Icons.refresh, color: AppColors.textSec, size: 18),
                    SizedBox(width: 8),
                    Text('Обновить', style: TextStyle(color: AppColors.textPrim)),
                  ])),
                  PopupMenuItem(value: 'delete', child: Row(children: [
                    Icon(Icons.delete_outline, color: AppColors.red, size: 18),
                    SizedBox(width: 8),
                    Text('Удалить', style: TextStyle(color: AppColors.red)),
                  ])),
                ],
              ),
            ]),
          ),

          // Stats row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              _StatChip(label: 'Серверов', value: '${servers.length}', color: AppColors.blue),
              const SizedBox(width: 8),
              if (sub.expires != null)
                _StatChip(
                  label: 'Осталось',
                  value: daysLeft > 0 ? '${daysLeft}д' : 'Истёк',
                  color: expiryColor,
                ),
            ]),
          ),

          // Server flags
          if (servers.isNotEmpty) ...[
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(spacing: 4, runSpacing: 4, children: servers.map((s) =>
                Tooltip(
                  message: '${s.name} — ${s.protocol.label}',
                  child: Text(s.flag, style: const TextStyle(fontSize: 22)),
                )
              ).toList()),
            ),
          ],
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, VpnProvider vpn) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Удалить подписку?', style: TextStyle(color: AppColors.textPrim)),
        content: const Text('Все серверы этой подписки тоже удалятся',
          style: TextStyle(color: AppColors.textSec)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          TextButton(
            onPressed: () { vpn.deleteSubscription(sub.id); Navigator.pop(context); },
            child: const Text('Удалить', style: TextStyle(color: AppColors.red)),
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label, value;
  final Color color;
  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Row(children: [
      Text(label, style: TextStyle(color: color.withOpacity(0.7), fontSize: 11)),
      const SizedBox(width: 6),
      Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w700)),
    ]),
  );
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('📦', style: TextStyle(fontSize: 56)),
        const SizedBox(height: 16),
        const Text('Нет подписок', style: TextStyle(
          color: AppColors.textPrim, fontSize: 18, fontWeight: FontWeight.w700,
        )),
        const SizedBox(height: 8),
        const Text('Добавь подписку по URL', style: TextStyle(color: AppColors.textSec)),
        const SizedBox(height: 24),
        GestureDetector(
          onTap: onAdd,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              gradient: AppColors.gradientGreen,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Text('+ Добавить подписку', style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.w700,
            )),
          ),
        ),
      ],
    ),
  );
}
